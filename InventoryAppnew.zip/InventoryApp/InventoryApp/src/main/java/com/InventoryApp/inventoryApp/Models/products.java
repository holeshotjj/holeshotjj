package com.InventoryApp.inventoryApp.Models;

import javax.persistence.*;

@Entity
@Table(name = "product")
public class products {
    @Id
    @Column(name = "id")
    public String id;
    @Column(name = "description")
    public String Description;
    @Column(name = "price")
    public String Price;
    @Column(name = "color")
    public String Color;

    public products()
    {

    }
    public products(String id, String Description, String Price, String Color) {
        this.id = id;
        this.Description = Description;
        this.Price = Price;
        this.Color = Color;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        this.Description = description;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        this.Price = price;
    }
    public String getColor() {
        return Color;
    }

    public void setColor(String color) {
        this.Color = color;
    }
}
