package com.InventoryApp.inventoryApp.Models;

import org.springframework.data.repository.CrudRepository;

public interface productsRepo extends CrudRepository<products, String> {
}
